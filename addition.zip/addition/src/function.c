unsigned char addition( unsigned char n1, unsigned char n2)
{
        unsigned char tmp;
        while ( n2 != 0) {
                tmp = (n1 & n2) << 1;
                n1 = n1 ^ n2;
                n2 = tmp;
        }
        return n1;
}
