unsigned int toggle_odd_bits(unsigned int num)
{
        unsigned int oddbits = num & 0x55;
        return oddbits;
}
