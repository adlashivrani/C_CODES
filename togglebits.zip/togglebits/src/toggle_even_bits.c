unsigned int toggle_even_bits(unsigned int num)
{
        unsigned int evenbits = num & 0xAA;
        return evenbits;
}
