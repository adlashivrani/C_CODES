#include<stdio.h>
unsigned int toggle_even_bits(unsigned int num);
unsigned int toggle_odd_bits(unsigned int num);
