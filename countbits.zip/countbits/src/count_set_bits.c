unsigned int count_set_bits( unsigned int num)
{
        unsigned int count = 0;
    // x holds one set digit at a time
    // starting from LSB to MSB of n.
    for (int x = 1; x <= num; x = x << 1)
        if ((x & num) != 0)
            count++;
    return count;
}
