#include<stdio.h>
unsigned int count_set_bits( unsigned int num);
unsigned int count_clear_bits(unsigned int num);
